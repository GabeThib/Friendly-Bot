<div align="center">
  <h1 align="center">~ Discord Selfbot ~</h1>
  <strong>A selfbot for Discord that is setup and ready to go in less than 5 minutes.</strong><br />(If you already have the required programs installed)<br /><br />
  <p align="center">
    <a href="https://github.com/feross/standard"><img src="https://cdn.rawgit.com/feross/standard/master/badge.svg"></a>
  <br>
</p>
</div>

# Discord Server Nuker

Are you pissed at a server that your staff in?

Do you fucking hate the server owner?

Do you want to watch ~~the world~~ a Discord server burn?

Well I got the perfect program for you! Server Nuker!

Server Nuker is a powerful Node.js program that will destroy any Discord server that you have Admin/Mod/Staff in.

# Disclaimer ⚠


This program is **very powerful.** It runs **very fast** on small servers but (less than 250 members). And it only takes a minute to **ban everyone in the server, and delete all roles/channels.**. **I am not responsible** for any damage you do with this tool, or any punishments you get from the server owners, **or even Discord Staff (They could ban your account for API abuse)**. Please use this tool on an alt account or on a bot account. Don't fucking blame me if your server got nuked with this.
If you want this Bot then please visit **https://rocketr.net/buy/452c2bf0a953** ☜

> Need help with finding your Discord token? then visit [here](https://github.com/Mydract/Discord-Nuker/wiki/%F0%9F%94%91-%7C-How-to-get-your-discord-token).

> If you're worried about getting banned or otherwised punished by Discord for using a selfbot, or you just haven't read the rules yet, see [here](https://github.com/Mydract/Discord-Nuker/wiki/SelfBot-Rules).

# Install

Download and install Node.js from https://nodejs.org

Download this repo as a .zip file

Unzip the .zip file to a folder 

Open config.json and put your user token in the config.json file.

Run the command `npm install` in the folder

Then run `node index.js`

Once the program has connected to the API, run one of the commands below in te server you want to destroy.

> Installing on the cloud with Heroku? Then visit here [here](https://github.com/Mydract/Discord-Nuker/wiki/Installing-on-the-cloud-with-Heroku).

# Commands

`!destroy` -**Bans everyone, deletes all channels and roles, and sets the server name to a raided message.**

`!overwrite` - Does the same thing as `!destroy`, but creates tons of channels and roles. Useful if you don't want the server owners to be able to recover from this.

`!baneveryone` - Bans everyone.

`!kickeveryone` - kicks everyone.

`!deleteroles` Deletes all roles.

`!deletechannels` Deletes all channels.

# In Action

[**Click Here! To See Action.**](https://www.youtube.com/watch?v=jxJtIWfiCa4)

# Servers Destroyed With Server-Nuker

-VaronBros Community (220 victims)

-Aurora Community (3.5K victims)

-Discord Store (1.2K victims)

-Looking For Gamers (5K victims)

-TLS Community (unknown if Server-Nuker was used) (1.8K victims)

-Midnight Falls (4.4K victims)

# Buy me a cup of coffee ☕

This bot is open source and always will be, even if I don't get donations. That said, I know there are people out there that may still want to donate just to show their appreciation so this is for you guys. Thanks in advance!

[**Donate Here!**](https://www.paypal.me/MirzaEmon) ☕
 
